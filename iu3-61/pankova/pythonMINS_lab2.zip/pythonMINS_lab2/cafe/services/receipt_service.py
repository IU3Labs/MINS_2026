from cafe.exceptions.cafe_exceptions import EmptyOrderException


class ReceiptService:
    # чек

    def create_receipt(self, order):
        if order.is_empty():
            raise EmptyOrderException("Нельзя сформировать чек для пустого заказа.")

        lines = []
        lines.append("===== ЧЕК =====")
        lines.append(f"Столик: {order.table_number}")

        for item in order.items:
            lines.append(str(item))

        lines.append("----------------")
        lines.append(f"Итого: {order.get_total():.2f} руб.")
        lines.append("================")

        return "\n".join(lines)