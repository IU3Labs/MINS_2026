from cafe.domain.order import Order
from cafe.exceptions.cafe_exceptions import (
    CafeException,
    EmptyOrderException
)
from cafe.payments.payment_factory import PaymentFactory


class OrderService:
    def __init__(self, unit_of_work):
        self._uow = unit_of_work

    def create_order(self, table_number):
        with self._uow as uow:
            order = Order(table_number)
            uow.orders.add(order)
            uow.commit()
            return order

    def add_item_to_order(self, table_number, item_name, quantity):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            menu_item = uow.menus.find_by_name(item_name)
            if menu_item is None:
                raise CafeException(f"Блюдо '{item_name}' не найдено в меню.")

            order.add_item(menu_item, quantity)
            uow.orders.update(order)
            uow.commit()

    def get_order(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")
            return order

    def get_all_orders(self):
        with self._uow as uow:
            return uow.orders.get_all()

    def pay_order(self, table_number, payment_type):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            if order.is_empty():
                raise EmptyOrderException("Нельзя оплатить пустой заказ.")

            payment_strategy = PaymentFactory.create(payment_type)
            payment_result = payment_strategy.pay(order.get_total())

            order.mark_as_paid()
            uow.orders.update(order)
            uow.commit()

            return payment_result

    def remove_order(self, table_number):
        with self._uow as uow:
            uow.orders.remove(table_number)
            uow.commit()