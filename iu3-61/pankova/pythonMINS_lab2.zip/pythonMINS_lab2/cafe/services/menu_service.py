from cafe.exceptions.cafe_exceptions import MenuItemNotFoundException


class MenuService:
    def __init__(self, menu_repository):
        self.menu_repository = menu_repository

    def add_item(self, menu_item):
        self.menu_repository.add(menu_item)

    def get_menu(self):
        return self.menu_repository.get_all()

    def get_item_by_name(self, name):
        item = self.menu_repository.find_by_name(name)
        if item is None:
            raise MenuItemNotFoundException(f"Блюдо '{name}' не найдено.")
        return item