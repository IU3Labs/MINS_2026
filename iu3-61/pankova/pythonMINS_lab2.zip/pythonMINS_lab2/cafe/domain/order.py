from cafe.domain.order_item import OrderItem
from cafe.exceptions.cafe_exceptions import (
    InvalidQuantityException,
    EmptyOrderException,
    InvalidTableNumberException,
    OrderAlreadyPaidException
)


class Order:
    # заказ для конкретного стола

    def __init__(self, table_number):
        if table_number <= 0:
            raise InvalidTableNumberException("Номер столика должен быть больше 0.")

        self.table_number = table_number
        self.items = []
        self.is_paid = False

    def add_item(self, menu_item, quantity):
        if self.is_paid:
            raise OrderAlreadyPaidException("Нельзя добавлять блюда в оплаченный заказ.")

        if quantity <= 0:
            raise InvalidQuantityException("Количество должно быть больше 0.")

        for item in self.items:
            if item.menu_item.name.lower() == menu_item.name.lower():
                item.quantity += quantity
                return

        self.items.append(OrderItem(menu_item, quantity))

    def get_total(self):
        total = 0
        for item in self.items:
            total += item.get_cost()
        return total

    def is_empty(self):
        return len(self.items) == 0

    def mark_as_paid(self):
        if self.is_empty():
            raise EmptyOrderException("Нельзя оплатить пустой заказ.")

        if self.is_paid:
            raise OrderAlreadyPaidException("Заказ уже оплачен.")

        self.is_paid = True

    def __str__(self):
        if self.is_empty():
            return f"Заказ столика {self.table_number} пуст."

        lines = [f"Заказ столика {self.table_number}:"]
        for item in self.items:
            lines.append(str(item))
        lines.append(f"Итого: {self.get_total():.2f} руб.")
        lines.append(f"Статус оплаты: {'оплачен' if self.is_paid else 'не оплачен'}")
        return "\n".join(lines)