from cafe.domain.menu_item import MenuItem
from cafe.repositories.menu_repository import MenuRepository
from cafe.repositories.order_repository import OrderRepository
from cafe.services.menu_service import MenuService
from cafe.services.order_service import OrderService
from cafe.services.receipt_service import ReceiptService
from cafe.ui.console_ui import ConsoleUI
from cafe.unit_of_work import InMemoryUnitOfWork


class AppBuilder:
    @staticmethod
    def build():
        menu_repository = MenuRepository()
        order_repository = OrderRepository()

        menu_repository.add(MenuItem("Капучино", 200))
        menu_repository.add(MenuItem("Латте", 220))
        menu_repository.add(MenuItem("Чизкейк", 250))
        menu_repository.add(MenuItem("Американо", 180))

        menu_service = MenuService(menu_repository)
        uow = InMemoryUnitOfWork(menu_repository, order_repository)
        order_service = OrderService(uow)
        receipt_service = ReceiptService()

        return ConsoleUI(
            menu_service=menu_service,
            order_service=order_service,
            receipt_service=receipt_service
        )