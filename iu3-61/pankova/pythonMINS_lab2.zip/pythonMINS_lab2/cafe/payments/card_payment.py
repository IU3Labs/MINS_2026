from cafe.payments.payment_strategy import PaymentStrategy


class CardPayment(PaymentStrategy):
    def pay(self, amount):
        return f"Оплата картой: {amount:.2f} руб."