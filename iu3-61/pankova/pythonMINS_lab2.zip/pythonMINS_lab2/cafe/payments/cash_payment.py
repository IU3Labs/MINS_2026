from cafe.payments.payment_strategy import PaymentStrategy


class CashPayment(PaymentStrategy):
    def pay(self, amount):
        return f"Оплата наличными: {amount:.2f} руб."