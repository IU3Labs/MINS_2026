from cafe.exceptions.cafe_exceptions import InvalidPaymentChoiceException
from cafe.payments.card_payment import CardPayment
from cafe.payments.cash_payment import CashPayment


class PaymentFactory:
    @staticmethod
    def create(payment_type: str):
        payment_type = payment_type.lower()

        if payment_type == "cash":
            return CashPayment()
        if payment_type == "card":
            return CardPayment()

        raise InvalidPaymentChoiceException(
            "Некорректный способ оплаты. Доступно: cash или card."
        )