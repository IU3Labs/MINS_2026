from cafe.domain.order import Order
from cafe.exceptions.cafe_exceptions import (
    CafeException,
    EmptyOrderException
)
from cafe.payments.payment_factory import MagicPaymentFactory


class OrderService:
    def __init__(self, unit_of_work):
        self._uow = unit_of_work

    def create_order(self, table_number):
        with self._uow as uow:
            order = Order(table_number)
            uow.orders.add(order)
            uow.commit()
            return order

    def add_item_to_order(self, table_number, item_name, quantity):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            menu_item = uow.menus.find_by_name(item_name)
            if menu_item is None:
                raise CafeException(f"Блюдо '{item_name}' не найдено в меню.")

            order.add_item(menu_item, quantity)
            uow.orders.update(order)
            uow.commit()

    def get_order(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")
            return order

    def get_all_orders(self):
        with self._uow as uow:
            return uow.orders.get_all()

    def mark_order_as_ready(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.mark_as_ready()
            uow.orders.update(order)
            uow.commit()

    def pay_order(self, table_number, payment_type, currency):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            if order.is_empty():
                raise EmptyOrderException("Нельзя оплатить пустой заказ.")

            payment_code = f"{payment_type.lower()}_{currency.lower()}"
            payment_info = MagicPaymentFactory.create(payment_code)
            exchange_rate = payment_info["exchange_rate"]
            client_amount = order.get_total() / exchange_rate
            payment_result = payment_info["strategy"].pay(
                client_amount=client_amount,
                currency_label=payment_info["currency_label"],
                ruble_amount=order.get_total(),
            )

            order.mark_as_paid(
                payment_method=payment_info["payment_method_label"],
                payment_currency=payment_info["currency_code"],
                client_paid_amount=client_amount,
                cafe_received_rubles=order.get_total(),
            )
            uow.orders.update(order)
            uow.commit()

            return payment_result

    def force_set_created_status(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.force_set_status("создан")
            uow.orders.update(order)
            uow.commit()
            return "Статус заказа вручную изменен на 'создан'."

    def force_set_preparing_status(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.force_set_status("готовится")
            uow.orders.update(order)
            uow.commit()
            return "Статус заказа вручную изменен на 'готовится'."

    def force_set_ready_status(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.force_set_status("готов")
            uow.orders.update(order)
            uow.commit()
            return "Статус заказа вручную изменен на 'готов'."

    def force_set_paid_status(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.force_set_status("оплачен")
            uow.orders.update(order)
            uow.commit()
            return "Статус заказа вручную изменен на 'оплачен'."

    def remove_order(self, table_number):
        with self._uow as uow:
            uow.orders.remove(table_number)
            uow.commit()
