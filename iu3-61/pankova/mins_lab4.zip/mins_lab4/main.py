from cafe.app_builder import AppBuilder


def main():
    app = AppBuilder.build()
    app.run()


if __name__ == "__main__":
    main()