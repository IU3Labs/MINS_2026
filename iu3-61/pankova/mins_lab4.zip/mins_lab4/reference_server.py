from concurrent import futures
import logging
import sys

import grpc

from cafe.domain.menu_item import MenuItem
from proto import reference_pb2
from proto import reference_pb2_grpc


logger = logging.getLogger("reference_service")
logger.setLevel(logging.INFO)
logger.handlers.clear()

handler = logging.StreamHandler(sys.stdout)
handler.setLevel(logging.INFO)

formatter = logging.Formatter(
    "%(asctime)s [Reference Service] %(levelname)s %(message)s"
)

handler.setFormatter(formatter)
logger.addHandler(handler)
logger.propagate = False


class ReferenceService(reference_pb2_grpc.ReferenceServiceServicer):
    def __init__(self):
        self.menu_items = [
            MenuItem("Капучино", 200),
            MenuItem("Латте", 220),
            MenuItem("Чизкейк", 250),
            MenuItem("Американо", 180),
        ]

        self.payment_info = {
            ("cash", "rub"): ("RUB", "RUB", 1.0, "наличные"),
            ("card", "rub"): ("RUB", "RUB", 1.0, "карта"),

            ("cash", "usd"): ("USD", "USD", 90.0, "наличные"),
            ("card", "usd"): ("USD", "USD", 90.0, "карта"),

            ("cash", "eur"): ("EUR", "EUR", 98.0, "наличные"),
            ("card", "eur"): ("EUR", "EUR", 98.0, "карта"),

            ("cash", "cny"): ("CNY", "CNY", 12.5, "наличные"),
            ("card", "cny"): ("CNY", "CNY", 12.5, "карта"),
        }

    def GetMenu(self, request, context):
        logger.info(
            "trace_id=%s Получен запрос на получение меню",
            request.trace_id
        )

        return reference_pb2.GetMenuResponse(
            items=[
                reference_pb2.MenuItemDto(
                    name=item.name,
                    price=item.price
                )
                for item in self.menu_items
            ]
        )

    def GetMenuItem(self, request, context):
        logger.info(
            "trace_id=%s Получен запрос на проверку блюда: %s",
            request.trace_id,
            request.name
        )

        for item in self.menu_items:
            if item.name.lower() == request.name.lower():
                logger.info(
                    "trace_id=%s Блюдо найдено: %s, цена=%s",
                    request.trace_id,
                    item.name,
                    item.price
                )

                return reference_pb2.GetMenuItemResponse(
                    found=True,
                    name=item.name,
                    price=item.price
                )

        logger.warning(
            "trace_id=%s status=%s Блюдо не найдено: %s",
            request.trace_id,
            grpc.StatusCode.NOT_FOUND.name,
            request.name
        )

        context.abort(
            grpc.StatusCode.NOT_FOUND,
            f"Блюдо '{request.name}' не найдено в меню."
        )

    def GetPaymentInfo(self, request, context):
        logger.info(
            "trace_id=%s Получен запрос на проверку оплаты: payment_type=%s, currency=%s",
            request.trace_id,
            request.payment_type,
            request.currency
        )

        payment_type = request.payment_type.lower()
        currency = request.currency.lower()

        if payment_type not in ("cash", "card"):
            logger.warning(
                "trace_id=%s status=%s Некорректный способ оплаты: %s",
                request.trace_id,
                grpc.StatusCode.INVALID_ARGUMENT.name,
                request.payment_type
            )

            context.abort(
                grpc.StatusCode.INVALID_ARGUMENT,
                "Некорректный способ оплаты. Доступно: cash или card."
            )

        if currency not in ("rub", "usd", "eur", "cny"):
            logger.warning(
                "trace_id=%s status=%s Некорректная валюта: %s",
                request.trace_id,
                grpc.StatusCode.INVALID_ARGUMENT.name,
                request.currency
            )

            context.abort(
                grpc.StatusCode.INVALID_ARGUMENT,
                "Некорректная валюта. Доступно: rub, usd, eur, cny."
            )

        key = (payment_type, currency)
        currency_label, currency_code, exchange_rate, payment_method_label = self.payment_info[key]

        logger.info(
            "trace_id=%s Оплата проверена: method=%s, currency=%s, exchange_rate=%s",
            request.trace_id,
            payment_method_label,
            currency_code,
            exchange_rate
        )

        return reference_pb2.GetPaymentInfoResponse(
            success=True,
            currency_label=currency_label,
            currency_code=currency_code,
            exchange_rate=exchange_rate,
            payment_method_label=payment_method_label
        )

def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))

    reference_pb2_grpc.add_ReferenceServiceServicer_to_server(
        ReferenceService(),
        server
    )

    server.add_insecure_port("[::]:50051")
    server.start()

    logger.info("Reference Service запущен на порту 50051")

    server.wait_for_termination()


if __name__ == "__main__":
    serve()