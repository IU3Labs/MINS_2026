import logging
import uuid

from cafe.domain.order import Order
from cafe.exceptions.cafe_exceptions import (
    CafeException,
    EmptyOrderException
)
from cafe.payments.card_payment import CardPayment
from cafe.payments.cash_payment import CashPayment


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [Core Service] %(levelname)s %(message)s"
)


class OrderService:
    def __init__(self, unit_of_work, reference_client):
        self._uow = unit_of_work
        self.reference_client = reference_client

    def create_order(self, table_number):
        trace_id = str(uuid.uuid4())

        logging.info(
            f"trace_id={trace_id} Создание заказа для столика {table_number}"
        )

        with self._uow as uow:
            order = Order(table_number)
            uow.orders.add(order)
            uow.commit()
            return order

    def add_item_to_order(self, table_number, item_name, quantity):
        trace_id = str(uuid.uuid4())

        logging.info(
            f"trace_id={trace_id} Добавление блюда в заказ: "
            f"столик={table_number}, блюдо={item_name}, количество={quantity}"
        )

        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            menu_item = self.reference_client.get_menu_item(
                name=item_name,
                trace_id=trace_id
            )

            order.add_item(menu_item, quantity)
            uow.orders.update(order)
            uow.commit()

    def get_order(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")
            return order

    def get_all_orders(self):
        with self._uow as uow:
            return uow.orders.get_all()

    def mark_order_as_ready(self, table_number):
        trace_id = str(uuid.uuid4())

        logging.info(
            f"trace_id={trace_id} Перевод заказа в статус 'готов': "
            f"столик={table_number}"
        )

        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.mark_as_ready()
            uow.orders.update(order)
            uow.commit()

    def pay_order(self, table_number, payment_type, currency):
        trace_id = str(uuid.uuid4())

        logging.info(
            f"trace_id={trace_id} Оплата заказа: "
            f"столик={table_number}, способ={payment_type}, валюта={currency}"
        )

        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            if order.is_empty():
                raise EmptyOrderException("Нельзя оплатить пустой заказ.")

            payment_info = self.reference_client.get_payment_info(
                payment_type=payment_type,
                currency=currency,
                trace_id=trace_id
            )

            exchange_rate = payment_info["exchange_rate"]
            client_amount = order.get_total() / exchange_rate

            if payment_type.lower() == "cash":
                payment_strategy = CashPayment()
            elif payment_type.lower() == "card":
                payment_strategy = CardPayment()
            else:
                raise CafeException("Некорректный способ оплаты. Доступно: cash или card.")

            payment_result = payment_strategy.pay(
                client_amount=client_amount,
                currency_label=payment_info["currency_label"],
                ruble_amount=order.get_total(),
            )

            order.mark_as_paid(
                payment_method=payment_info["payment_method_label"],
                payment_currency=payment_info["currency_code"],
                client_paid_amount=client_amount,
                cafe_received_rubles=order.get_total(),
            )

            uow.orders.update(order)
            uow.commit()

            return payment_result

    def force_set_created_status(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.force_set_status("создан")
            uow.orders.update(order)
            uow.commit()
            return "Статус заказа вручную изменен на 'создан'."

    def force_set_preparing_status(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.force_set_status("готовится")
            uow.orders.update(order)
            uow.commit()
            return "Статус заказа вручную изменен на 'готовится'."

    def force_set_ready_status(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.force_set_status("готов")
            uow.orders.update(order)
            uow.commit()
            return "Статус заказа вручную изменен на 'готов'."

    def force_set_paid_status(self, table_number):
        with self._uow as uow:
            order = uow.orders.get_by_table_number(table_number)
            if order is None:
                raise CafeException(f"Заказ для столика {table_number} не найден.")

            order.force_set_status("оплачен")
            uow.orders.update(order)
            uow.commit()
            return "Статус заказа вручную изменен на 'оплачен'."

    def remove_order(self, table_number):
        with self._uow as uow:
            uow.orders.remove(table_number)
            uow.commit()