from cafe.exceptions.cafe_exceptions import EmptyOrderException


class ReceiptService:
    # чек

    def create_receipt(self, order):
        if order.is_empty():
            raise EmptyOrderException("Нельзя сформировать чек для пустого заказа.")

        lines = []
        lines.append("===== ЧЕК =====")
        lines.append(f"Столик: {order.table_number}")

        for item in order.items:
            lines.append(str(item))

        lines.append("----------------")
        lines.append(f"Итого: {order.get_total():.2f} руб.")
        lines.append(f"Статус заказа: {order.status}")
        if order.is_paid and order.payment_method is not None:
            lines.append(f"Способ оплаты: {order.payment_method}")
            lines.append(f"Валюта клиента: {order.payment_currency}")
            lines.append(f"Клиент оплатил: {order.client_paid_amount:.2f} {order.payment_currency}")
            lines.append(f"Кафе получило: {order.cafe_received_rubles:.2f} руб.")
        lines.append("================")

        return "\n".join(lines)
