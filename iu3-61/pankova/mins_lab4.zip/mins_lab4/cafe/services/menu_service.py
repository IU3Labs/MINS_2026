import uuid


class MenuService:
    def __init__(self, reference_client):
        self.reference_client = reference_client

    def get_menu(self):
        trace_id = str(uuid.uuid4())
        return self.reference_client.get_menu(trace_id)

    def get_item_by_name(self, name):
        trace_id = str(uuid.uuid4())
        return self.reference_client.get_menu_item(name, trace_id)