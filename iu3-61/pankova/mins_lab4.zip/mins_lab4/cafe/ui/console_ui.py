from cafe.exceptions.cafe_exceptions import CafeException


class ConsoleUI:
    def __init__(self, menu_service, order_service, receipt_service):
        self.menu_service = menu_service
        self.order_service = order_service
        self.receipt_service = receipt_service

    def run(self):
        while True:
            print("\n===== Система кафе =====")
            print("1. Показать меню")
            print("2. Создать заказ")
            print("3. Добавить блюдо в заказ")
            print("4. Показать заказ")
            print("5. Показать чек")
            print("6. Оплатить заказ")
            print("7. Отметить заказ как готовый")
            print("8. Вручную установить статус 'создан'")
            print("9. Вручную установить статус 'готовится'")
            print("10. Вручную установить статус 'готов'")
            print("11. Вручную установить статус 'оплачен'")
            print("12. Показать все заказы")
            print("0. Выход")

            choice = input("Выберите действие: ").strip()

            try:
                if choice == "1":
                    self.show_menu()
                elif choice == "2":
                    self.create_order()
                elif choice == "3":
                    self.add_item_to_order()
                elif choice == "4":
                    self.show_order()
                elif choice == "5":
                    self.show_receipt()
                elif choice == "6":
                    self.pay_order()
                elif choice == "7":
                    self.mark_order_as_ready()
                elif choice == "8":
                    self.change_status_to_created()
                elif choice == "9":
                    self.change_status_to_preparing()
                elif choice == "10":
                    self.change_status_to_ready()
                elif choice == "11":
                    self.change_status_to_paid()
                elif choice == "12":
                    self.show_all_orders()
                elif choice == "0":
                    print("Выход из программы.")
                    break
                else:
                    print("Некорректный пункт меню.")
            except CafeException as e:
                print(f"Ошибка: {e}")
            except ValueError:
                print("Ошибка: введите корректное число.")

    def show_menu(self):
        menu = self.menu_service.get_menu()
        print("\n===== МЕНЮ =====")
        for item in menu:
            print(item)

    def create_order(self):
        table_number = int(input("Введите номер столика: "))
        self.order_service.create_order(table_number)
        print("Заказ успешно создан.")

    def add_item_to_order(self):
        table_number = int(input("Введите номер столика: "))
        item_name = input("Введите название блюда: ").strip()
        quantity = int(input("Введите количество: "))

        self.order_service.add_item_to_order(table_number, item_name, quantity)
        print("Блюдо добавлено в заказ.")

    def show_order(self):
        table_number = int(input("Введите номер столика: "))
        order = self.order_service.get_order(table_number)
        print("\n" + str(order))

    def show_receipt(self):
        table_number = int(input("Введите номер столика: "))
        order = self.order_service.get_order(table_number)
        receipt = self.receipt_service.create_receipt(order)
        print("\n" + receipt)

    def pay_order(self):
        table_number = int(input("Введите номер столика: "))
        payment_type = input("Введите способ оплаты (cash/card): ").strip().lower()
        currency = input("Введите валюту клиента (rub/usd/eur/cny): ").strip().lower()

        result = self.order_service.pay_order(table_number, payment_type, currency)
        print(result)
        print("Заказ успешно оплачен, на счет кафе зачислены рубли.")

    def mark_order_as_ready(self):
        table_number = int(input("Введите номер столика: "))
        self.order_service.mark_order_as_ready(table_number)
        print("Заказ переведен в статус 'готов'.")

    def change_status_to_created(self):
        table_number = int(input("Введите номер столика: "))
        result = self.order_service.force_set_created_status(table_number)
        print(result)
        print("Статус заказа был изменен вручную в обход стандартной процедуры.")

    def change_status_to_preparing(self):
        table_number = int(input("Введите номер столика: "))
        result = self.order_service.force_set_preparing_status(table_number)
        print(result)
        print("Статус заказа был изменен вручную в обход стандартной процедуры.")

    def change_status_to_ready(self):
        table_number = int(input("Введите номер столика: "))
        result = self.order_service.force_set_ready_status(table_number)
        print(result)
        print("Статус заказа был изменен вручную в обход стандартной процедуры.")

    def change_status_to_paid(self):
        table_number = int(input("Введите номер столика: "))
        result = self.order_service.force_set_paid_status(table_number)
        print(result)
        print("Статус заказа был изменен вручную в обход стандартной процедуры.")

    def show_all_orders(self):
        orders = self.order_service.get_all_orders()

        if not orders:
            print("Заказов пока нет.")
            return

        print("\n===== ВСЕ ЗАКАЗЫ =====")
        for order in orders:
            print(order)
            print("-" * 30)
