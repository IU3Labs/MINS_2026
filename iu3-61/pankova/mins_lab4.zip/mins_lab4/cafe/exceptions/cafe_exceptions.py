class CafeException(Exception):
    pass


class DuplicateOrderException(CafeException):
    pass


class InvalidQuantityException(CafeException):
    pass


class EmptyOrderException(CafeException):
    pass


class InvalidTableNumberException(CafeException):
    pass


class OrderAlreadyPaidException(CafeException):
    pass


class MenuItemNotFoundException(CafeException):
    pass


class InvalidPaymentChoiceException(CafeException):
    pass


class InvalidOrderStatusException(CafeException):
    pass


class InvalidStatusTransitionException(CafeException):
    pass


class InvalidCurrencyChoiceException(CafeException):
    pass
