from cafe.exceptions.cafe_exceptions import DuplicateOrderException


class OrderRepository:
    # заказы в памяти

    def __init__(self):
        self.orders = {}

    def add(self, order):
        if order.table_number in self.orders:
            raise DuplicateOrderException(
                f"Заказ для столика {order.table_number} уже существует."
            )
        self.orders[order.table_number] = order

    def get_by_table_number(self, table_number):
        return self.orders.get(table_number)

    def get_all(self):
        return list(self.orders.values())

    def update(self, order):
        self.orders[order.table_number] = order

    def remove(self, table_number):
        if table_number in self.orders:
            del self.orders[table_number]