class MenuRepository:
    # блюда в памяти

    def __init__(self):
        self.menu_items = []

    def add(self, menu_item):
        self.menu_items.append(menu_item)

    def get_all(self):
        return self.menu_items

    def find_by_name(self, name):
        for item in self.menu_items:
            if item.name.lower() == name.lower():
                return item
        return None