import grpc

from cafe.domain.menu_item import MenuItem
from cafe.exceptions.cafe_exceptions import CafeException
from proto import reference_pb2
from proto import reference_pb2_grpc


class ReferenceClient:
    def __init__(self, host="localhost", port=50051):
        self.address = f"{host}:{port}"

    def _get_stub(self):
        channel = grpc.insecure_channel(self.address)
        return reference_pb2_grpc.ReferenceServiceStub(channel)

    def get_menu(self, trace_id):
        try:
            stub = self._get_stub()

            response = stub.GetMenu(
                reference_pb2.GetMenuRequest(trace_id=trace_id),
                timeout=3
            )

            return [
                MenuItem(item.name, item.price)
                for item in response.items
            ]

        except grpc.RpcError as error:
            if error.code() == grpc.StatusCode.UNAVAILABLE:
                raise CafeException(
                    "Reference Service недоступен. Невозможно получить меню."
                )

            if error.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
                raise CafeException(
                    "Reference Service не ответил за отведенное время."
                )

            raise CafeException(
                f"Ошибка получения меню: {error.details()}"
            )

    def get_menu_item(self, name, trace_id):
        try:
            stub = self._get_stub()

            response = stub.GetMenuItem(
                reference_pb2.GetMenuItemRequest(
                    trace_id=trace_id,
                    name=name
                ),
                timeout=3
            )

            return MenuItem(response.name, response.price)

        except grpc.RpcError as error:
            if error.code() == grpc.StatusCode.NOT_FOUND:
                raise CafeException(error.details())

            if error.code() == grpc.StatusCode.UNAVAILABLE:
                raise CafeException(
                    "Reference Service недоступен. Невозможно проверить блюдо."
                )

            if error.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
                raise CafeException(
                    "Reference Service не ответил за отведенное время."
                )

            raise CafeException(
                f"Ошибка проверки блюда: {error.details()}"
            )

    def get_payment_info(self, payment_type, currency, trace_id):
        try:
            stub = self._get_stub()

            response = stub.GetPaymentInfo(
                reference_pb2.GetPaymentInfoRequest(
                    trace_id=trace_id,
                    payment_type=payment_type,
                    currency=currency
                ),
                timeout=3
            )

            return {
                "currency_label": response.currency_label,
                "currency_code": response.currency_code,
                "exchange_rate": response.exchange_rate,
                "payment_method_label": response.payment_method_label,
            }

        except grpc.RpcError as error:
            if error.code() == grpc.StatusCode.INVALID_ARGUMENT:
                raise CafeException(error.details())

            if error.code() == grpc.StatusCode.UNAVAILABLE:
                raise CafeException(
                    "Reference Service недоступен. Невозможно выполнить оплату."
                )

            if error.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
                raise CafeException(
                    "Reference Service не ответил за отведенное время."
                )

            raise CafeException(
                f"Ошибка получения информации об оплате: {error.details()}"
            )