from cafe.payments.payment_strategy import PaymentStrategy


class CardPayment(PaymentStrategy):
    def pay(self, client_amount, currency_label, ruble_amount):
        return (
            f"Оплата картой: клиент заплатил {client_amount:.2f} {currency_label}, "
            f"кафе получило {ruble_amount:.2f} руб."
        )
