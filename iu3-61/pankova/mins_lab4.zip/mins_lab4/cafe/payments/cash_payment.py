from cafe.payments.payment_strategy import PaymentStrategy


class CashPayment(PaymentStrategy):
    def pay(self, client_amount, currency_label, ruble_amount):
        return (
            f"Оплата наличными: клиент заплатил {client_amount:.2f} {currency_label}, "
            f"кафе получило {ruble_amount:.2f} руб."
        )
