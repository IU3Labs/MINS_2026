from cafe.exceptions.cafe_exceptions import (
    InvalidCurrencyChoiceException,
    InvalidPaymentChoiceException,
)
from cafe.payments.card_payment import CardPayment
from cafe.payments.cash_payment import CashPayment


class MagicPaymentFactory:
    @staticmethod
    def create(payment_code: str):
        payment_code = payment_code.lower()

        if payment_code == "cash_rub":
            return {
                "strategy": CashPayment(),
                "currency_label": "RUB",
                "currency_code": "RUB",
                "exchange_rate": 1.0,
                "payment_method_label": "наличные",
            }
        if payment_code == "card_rub":
            return {
                "strategy": CardPayment(),
                "currency_label": "RUB",
                "currency_code": "RUB",
                "exchange_rate": 1.0,
                "payment_method_label": "карта",
            }
        if payment_code == "cash_usd":
            return {
                "strategy": CashPayment(),
                "currency_label": "USD",
                "currency_code": "USD",
                "exchange_rate": 90.0,
                "payment_method_label": "наличные",
            }
        if payment_code == "card_usd":
            return {
                "strategy": CardPayment(),
                "currency_label": "USD",
                "currency_code": "USD",
                "exchange_rate": 90.0,
                "payment_method_label": "карта",
            }
        if payment_code == "cash_eur":
            return {
                "strategy": CashPayment(),
                "currency_label": "EUR",
                "currency_code": "EUR",
                "exchange_rate": 98.0,
                "payment_method_label": "наличные",
            }
        if payment_code == "card_eur":
            return {
                "strategy": CardPayment(),
                "currency_label": "EUR",
                "currency_code": "EUR",
                "exchange_rate": 98.0,
                "payment_method_label": "карта",
            }
        if payment_code == "cash_cny":
            return {
                "strategy": CashPayment(),
                "currency_label": "CNY",
                "currency_code": "CNY",
                "exchange_rate": 12.5,
                "payment_method_label": "наличные",
            }
        if payment_code == "card_cny":
            return {
                "strategy": CardPayment(),
                "currency_label": "CNY",
                "currency_code": "CNY",
                "exchange_rate": 12.5,
                "payment_method_label": "карта",
            }

        if payment_code.startswith("cash_") or payment_code.startswith("card_"):
            raise InvalidCurrencyChoiceException(
                "Некорректная валюта. Доступно: rub, usd, eur, cny."
            )

        raise InvalidPaymentChoiceException(
            "Некорректный способ оплаты. Доступно: cash или card."
        )
