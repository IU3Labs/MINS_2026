from abc import ABC, abstractmethod


class PaymentStrategy(ABC):
    @abstractmethod
    def pay(self, client_amount, currency_label, ruble_amount):
        pass
