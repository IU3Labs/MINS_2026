from cafe.domain.order_item import OrderItem
from cafe.exceptions.cafe_exceptions import (
    InvalidQuantityException,
    EmptyOrderException,
    InvalidTableNumberException,
    OrderAlreadyPaidException,
    InvalidOrderStatusException,
    InvalidStatusTransitionException
)

STATUS_CREATED = "создан"
STATUS_PREPARING = "готовится"
STATUS_READY = "готов"
STATUS_PAID = "оплачен"

AVAILABLE_STATUSES = (
    STATUS_CREATED,
    STATUS_PREPARING,
    STATUS_READY,
    STATUS_PAID,
)


class Order:
    # заказ для конкретного стола

    def __init__(self, table_number):
        if table_number <= 0:
            raise InvalidTableNumberException("Номер столика должен быть больше 0.")

        self.table_number = table_number
        self.items = []
        self.is_paid = False
        self.status = STATUS_CREATED
        self.payment_method = None
        self.payment_currency = None
        self.client_paid_amount = None
        self.cafe_received_rubles = None

    def add_item(self, menu_item, quantity):
        if self.is_paid:
            raise OrderAlreadyPaidException("Нельзя добавлять блюда в оплаченный заказ.")

        if quantity <= 0:
            raise InvalidQuantityException("Количество должно быть больше 0.")

        for item in self.items:
            if item.menu_item.name.lower() == menu_item.name.lower():
                item.quantity += quantity
                self.status = STATUS_PREPARING
                return

        self.items.append(OrderItem(menu_item, quantity))
        self.status = STATUS_PREPARING

    def get_total(self):
        total = 0
        for item in self.items:
            total += item.get_cost()
        return total

    def is_empty(self):
        return len(self.items) == 0

    def mark_as_ready(self):
        if self.is_empty():
            raise EmptyOrderException("Нельзя приготовить пустой заказ.")

        if self.status == STATUS_PAID:
            raise OrderAlreadyPaidException("Оплаченный заказ уже завершен.")

        if self.status != STATUS_PREPARING:
            raise InvalidStatusTransitionException(
                "Перевести в статус 'готов' можно только заказ в статусе 'готовится'."
            )

        self.status = STATUS_READY

    def mark_as_paid(self, payment_method=None, payment_currency=None,
                     client_paid_amount=None, cafe_received_rubles=None):
        if self.is_empty():
            raise EmptyOrderException("Нельзя оплатить пустой заказ.")

        if self.is_paid:
            raise OrderAlreadyPaidException("Заказ уже оплачен.")

        if self.status != STATUS_READY:
            raise InvalidStatusTransitionException(
                "Оплатить можно только заказ в статусе 'готов'."
            )

        self.is_paid = True
        self.status = STATUS_PAID
        self.payment_method = payment_method
        self.payment_currency = payment_currency
        self.client_paid_amount = client_paid_amount
        self.cafe_received_rubles = cafe_received_rubles

    def force_set_status(self, new_status):
        if new_status not in AVAILABLE_STATUSES:
            raise InvalidOrderStatusException(f"Неизвестный статус заказа: {new_status}.")

        self.status = new_status
        self.is_paid = new_status == STATUS_PAID
        if new_status != STATUS_PAID:
            self.payment_method = None
            self.payment_currency = None
            self.client_paid_amount = None
            self.cafe_received_rubles = None

    def __str__(self):
        if self.is_empty():
            return (
                f"Заказ столика {self.table_number} пуст.\n"
                f"Статус заказа: {self.status}"
            )

        lines = [f"Заказ столика {self.table_number}:"]
        for item in self.items:
            lines.append(str(item))
        lines.append(f"Итого: {self.get_total():.2f} руб.")
        lines.append(f"Статус заказа: {self.status}")
        lines.append(f"Статус оплаты: {'оплачен' if self.is_paid else 'не оплачен'}")
        if self.is_paid and self.payment_method is not None:
            lines.append(f"Способ оплаты: {self.payment_method}")
            lines.append(f"Валюта клиента: {self.payment_currency}")
            lines.append(f"Клиент оплатил: {self.client_paid_amount:.2f} {self.payment_currency}")
            lines.append(f"Кафе зачислено: {self.cafe_received_rubles:.2f} руб.")
        return "\n".join(lines)
