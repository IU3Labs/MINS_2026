from cafe.grpc.reference_client import ReferenceClient
from cafe.repositories.menu_repository import MenuRepository
from cafe.repositories.order_repository import OrderRepository
from cafe.services.menu_service import MenuService
from cafe.services.order_service import OrderService
from cafe.services.receipt_service import ReceiptService
from cafe.ui.console_ui import ConsoleUI
from cafe.unit_of_work.unit_of_work import InMemoryUnitOfWork


class AppBuilder:
    @staticmethod
    def build():
        reference_client = ReferenceClient()

        menu_repository = MenuRepository()
        order_repository = OrderRepository()

        menu_service = MenuService(reference_client)

        uow = InMemoryUnitOfWork(
            menu_repository=menu_repository,
            order_repository=order_repository
        )

        order_service = OrderService(
            unit_of_work=uow,
            reference_client=reference_client
        )

        receipt_service = ReceiptService()

        return ConsoleUI(
            menu_service=menu_service,
            order_service=order_service,
            receipt_service=receipt_service
        )