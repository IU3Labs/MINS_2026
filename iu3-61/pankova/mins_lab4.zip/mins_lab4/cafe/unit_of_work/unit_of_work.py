from copy import deepcopy

from cafe.repositories.menu_repository import MenuRepository
from cafe.repositories.order_repository import OrderRepository


class InMemoryUnitOfWork:
    def __init__(self, menu_repository: MenuRepository, order_repository: OrderRepository):
        self.menu_repository = menu_repository
        self.order_repository = order_repository

        self._menu_backup = None
        self._order_backup = None

    def __enter__(self):
        self._menu_backup = deepcopy(self.menu_repository)
        self._order_backup = deepcopy(self.order_repository)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.rollback()
        return False

    @property
    def menus(self):
        return self.menu_repository

    @property
    def orders(self):
        return self.order_repository

    def commit(self):
        self._menu_backup = None
        self._order_backup = None

    def rollback(self):
        if self._menu_backup is not None:
            self.menu_repository.__dict__.clear()
            self.menu_repository.__dict__.update(self._menu_backup.__dict__)

        if self._order_backup is not None:
            self.order_repository.__dict__.clear()
            self.order_repository.__dict__.update(self._order_backup.__dict__)