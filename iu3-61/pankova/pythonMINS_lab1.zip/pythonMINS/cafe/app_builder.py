from cafe.payments.factory import PaymentProcessorFactory
from cafe.payments.processors import (
    CashPaymentProcessor,
    CardPaymentProcessor,
    SbpPaymentProcessor,
)
from cafe.receipts.formatter import TextReceiptFormatter
from cafe.repositories.in_memory import (
    InMemoryMenuRepository,
    InMemoryTableRepository,
    InMemoryOrderRepository,
)
from cafe.services.menu_service import MenuService
from cafe.services.table_service import TableService
from cafe.services.order_service import OrderService
from cafe.services.report_service import ReportService
from cafe.services.receipt_service import ReceiptService
from cafe.ui.console_app import CafeConsoleApp


class AppBuilder:
    @staticmethod
    def build() -> CafeConsoleApp:
        menu_repository = InMemoryMenuRepository()
        table_repository = InMemoryTableRepository()
        order_repository = InMemoryOrderRepository()

        payment_factory = PaymentProcessorFactory(
            processors=[
                CashPaymentProcessor(),
                CardPaymentProcessor(),
                SbpPaymentProcessor(),
            ]
        )

        menu_service = MenuService(menu_repository)
        table_service = TableService(table_repository)
        order_service = OrderService(
            order_repository=order_repository,
            table_repository=table_repository,
            menu_repository=menu_repository,
            payment_factory=payment_factory,
        )
        report_service = ReportService(order_repository)
        receipt_service = ReceiptService(order_repository, TextReceiptFormatter())

        return CafeConsoleApp(
            menu_service=menu_service,
            table_service=table_service,
            order_service=order_service,
            report_service=report_service,
            receipt_service=receipt_service,
        )