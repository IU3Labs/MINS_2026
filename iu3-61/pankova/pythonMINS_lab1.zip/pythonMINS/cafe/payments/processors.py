from abc import ABC, abstractmethod

from cafe.domain.entities import Payment
from cafe.domain.enums import PaymentMethod


class PaymentProcessor(ABC):
    @abstractmethod
    def method(self) -> PaymentMethod:
        pass

    @abstractmethod
    def create_payment(self, amount: float) -> Payment:
        pass


class CashPaymentProcessor(PaymentProcessor):
    def method(self) -> PaymentMethod:
        return PaymentMethod.CASH

    def create_payment(self, amount: float) -> Payment:
        return Payment(method=self.method(), amount=amount)


class CardPaymentProcessor(PaymentProcessor):
    def method(self) -> PaymentMethod:
        return PaymentMethod.CARD

    def create_payment(self, amount: float) -> Payment:
        return Payment(method=self.method(), amount=amount)


class SbpPaymentProcessor(PaymentProcessor):
    def method(self) -> PaymentMethod:
        return PaymentMethod.SBP

    def create_payment(self, amount: float) -> Payment:
        return Payment(method=self.method(), amount=amount)
