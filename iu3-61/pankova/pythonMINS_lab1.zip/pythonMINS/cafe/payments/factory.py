from typing import Iterable

from cafe.domain.enums import PaymentMethod
from cafe.exceptions.exceptions import NotFoundError
from cafe.payments.processors import PaymentProcessor


class PaymentProcessorFactory:
    def __init__(self, processors: Iterable[PaymentProcessor]) -> None:
        self._processors = {processor.method(): processor for processor in processors}

    def get(self, method: PaymentMethod) -> PaymentProcessor:
        processor = self._processors.get(method)
        if processor is None:
            raise NotFoundError(f"Для способа оплаты {method.value} не найден обработчик")
        return processor