class CafeError(Exception): #Базовое исключение  информационной системы кафе
    pass


class ValidationError(CafeError): #Ошибка валидации входных данных
    pass


class NotFoundError(CafeError): #Сущность не найдена
    pass


class DuplicateError(CafeError): #Сущность уже существует
    pass


class BusinessRuleError(CafeError):  #Нарушение бизнес-правил
    pass


class MenuItemNotFoundError(NotFoundError):
    pass


class TableNotFoundError(NotFoundError):
    pass


class OrderNotFoundError(NotFoundError):
    pass


class TableOccupiedError(BusinessRuleError):
    pass


class OrderStateError(BusinessRuleError):
    pass