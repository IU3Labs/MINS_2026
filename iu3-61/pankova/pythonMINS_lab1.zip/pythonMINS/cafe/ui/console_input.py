from cafe.exceptions.exceptions import ValidationError


class ConsoleInput:
    @staticmethod
    def read_int(prompt: str) -> int:
        raw = input(prompt).strip()
        try:
            return int(raw)
        except ValueError as exc:
            raise ValidationError("Ожидалось целое число") from exc

    @staticmethod
    def read_float(prompt: str) -> float:
        raw = input(prompt).strip().replace(",", ".")
        try:
            return float(raw)
        except ValueError as exc:
            raise ValidationError("Ожидалось число") from exc

    @staticmethod
    def read_non_empty(prompt: str) -> str:
        value = input(prompt).strip()
        if not value:
            raise ValidationError("Строка не должна быть пустой")
        return value