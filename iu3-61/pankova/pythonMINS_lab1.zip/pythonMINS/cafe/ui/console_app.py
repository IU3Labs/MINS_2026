from cafe.domain.enums import DishCategory, PaymentMethod
from cafe.exceptions.exceptions import CafeError, ValidationError
from cafe.services.menu_service import MenuService
from cafe.services.table_service import TableService
from cafe.services.order_service import OrderService
from cafe.services.report_service import ReportService
from cafe.services.receipt_service import ReceiptService
from cafe.ui.console_input import ConsoleInput


class CafeConsoleApp:
    def __init__(
        self,
        menu_service: MenuService,
        table_service: TableService,
        order_service: OrderService,
        report_service: ReportService,
        receipt_service: ReceiptService,
    ) -> None:
        self._menu_service = menu_service
        self._table_service = table_service
        self._order_service = order_service
        self._report_service = report_service
        self._receipt_service = receipt_service

    def seed_demo_data(self) -> None:
        self._table_service.add_table(1, 2)
        self._table_service.add_table(2, 4)
        self._table_service.add_table(3, 6)

        self._menu_service.add_menu_item(1, "Цезарь", DishCategory.APPETIZER, 320)
        self._menu_service.add_menu_item(2, "Борщ", DishCategory.SOUP, 280)
        self._menu_service.add_menu_item(3, "Стейк", DishCategory.MAIN_COURSE, 890)
        self._menu_service.add_menu_item(4, "Лимонад", DishCategory.DRINK, 180)
        self._menu_service.add_menu_item(5, "Чизкейк", DishCategory.DESSERT, 260)

    def run(self) -> None:
        self.seed_demo_data()
        actions = {
            "1": self.show_menu_items,
            "2": self.show_tables,
            "3": self.create_order,
            "4": self.add_item_to_order,
            "5": self.pay_order,
            "6": self.close_order,
            "7": self.print_receipt,
            "8": self.show_report,
            "9": self.show_orders,
            "0": self.exit_app,
        }

        while True:
            self.print_main_menu()
            choice = input("Выберите действие: ").strip()
            action = actions.get(choice)
            if action is None:
                print("Неизвестная команда")
                continue
            try:
                action()
            except CafeError as error:
                print(f"Ошибка: {error}")
            except Exception as error:
                print(f"Непредвиденная ошибка: {error}")

    @staticmethod
    def print_main_menu() -> None:
        print("\n" + "=" * 50)
        print("   ИНФОРМАЦИОННАЯ СИСТЕМА КАФЕ")
        print("=" * 50)
        print("1. Показать меню")
        print("2. Показать столики")
        print("3. Создать заказ")
        print("4. Добавить блюдо в заказ")
        print("5. Оплатить заказ")
        print("6. Закрыть заказ")
        print("7. Сформировать чек")
        print("8. Показать отчет")
        print("9. Показать все заказы")
        print("0. Выход")

    def show_menu_items(self) -> None:
        print("\nМЕНЮ:")
        for item in self._menu_service.get_menu():
            print(
                f"ID={item.item_id} | {item.name} | {item.category.value} | {item.price:.2f} руб."
            )

    def show_tables(self) -> None:
        print("\nСТОЛИКИ:")
        for table in self._table_service.get_tables():
            print(f"Столик №{table.table_number}, мест: {table.seats}")

    def create_order(self) -> None:
        table_number = ConsoleInput.read_int("Введите номер столика: ")
        order = self._order_service.create_order_for_table(table_number)
        print(f"Заказ создан. ID заказа: {order.order_id}")

    def add_item_to_order(self) -> None:
        order_id = ConsoleInput.read_int("Введите ID заказа: ")
        item_id = ConsoleInput.read_int("Введите ID блюда: ")
        quantity = ConsoleInput.read_int("Введите количество: ")
        self._order_service.add_item_to_order(order_id, item_id, quantity)
        order = self._order_service.get_order(order_id)
        print(f"Блюдо добавлено. Текущая сумма заказа: {order.total:.2f} руб.")

    def pay_order(self) -> None:
        order_id = ConsoleInput.read_int("Введите ID заказа: ")
        order = self._order_service.get_order(order_id)
        print(f"Сумма к оплате: {order.total:.2f} руб.")
        print("Способы оплаты: 1 - Наличные, 2 - Карта, 3 - СБП")
        method_code = ConsoleInput.read_int("Выберите способ оплаты: ")
        amount = ConsoleInput.read_float(
            "Введите сумму оплаты (или введите точную сумму заказа): "
        )

        mapping = {
            1: PaymentMethod.CASH,
            2: PaymentMethod.CARD,
            3: PaymentMethod.SBP,
        }
        method = mapping.get(method_code)
        if method is None:
            raise ValidationError("Некорректный способ оплаты")

        self._order_service.pay_order(order_id, method, amount)
        print(f"Заказ успешно оплачен. Сумма заказа: {order.total:.2f} руб.")

    def close_order(self) -> None:
        order_id = ConsoleInput.read_int("Введите ID заказа: ")
        self._order_service.close_order(order_id)
        print("Заказ закрыт")

    def print_receipt(self) -> None:
        order_id = ConsoleInput.read_int("Введите ID заказа: ")
        receipt = self._receipt_service.generate_receipt(order_id)
        print("\n" + receipt)

    def show_report(self) -> None:
        print("\n" + self._report_service.build_sales_report())

    def show_orders(self) -> None:
        print("\nЗАКАЗЫ:")
        orders = self._order_service.get_all_orders()
        if not orders:
            print("Заказов пока нет")
            return
        for order in orders:
            print(
                f"ID={order.order_id} | Столик={order.table_number} | "
                f"Статус={order.status.value} | Сумма={order.total:.2f} руб."
            )

    @staticmethod
    def exit_app() -> None:
        raise SystemExit("Выход из программы")