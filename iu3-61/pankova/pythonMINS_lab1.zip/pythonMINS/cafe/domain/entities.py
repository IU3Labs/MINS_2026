from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional

from cafe.domain.enums import DishCategory, PaymentMethod, OrderStatus
from cafe.exceptions.exceptions import (
    ValidationError,
    BusinessRuleError,
    OrderStateError,
)


@dataclass(frozen=True)
class MenuItem:
    item_id: int
    name: str
    category: DishCategory
    price: float

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValidationError("Название блюда не может быть пустым")
        if self.price <= 0:
            raise ValidationError("Цена блюда должна быть больше 0")


@dataclass(frozen=True)
class CafeTable:
    table_number: int
    seats: int

    def __post_init__(self) -> None:
        if self.table_number <= 0:
            raise ValidationError("Номер столика должен быть положительным")
        if self.seats <= 0:
            raise ValidationError("Количество мест должно быть положительным")


@dataclass(frozen=True)
class OrderLine:
    menu_item: MenuItem
    quantity: int

    def __post_init__(self) -> None:
        if self.quantity <= 0:
            raise ValidationError("Количество позиций должно быть положительным")

    @property
    def line_total(self) -> float:
        return self.menu_item.price * self.quantity


@dataclass
class Payment:
    method: PaymentMethod
    amount: float
    paid_at: datetime = field(default_factory=datetime.now)

    def __post_init__(self) -> None:
        if self.amount <= 0:
            raise ValidationError("Сумма оплаты должна быть больше 0")


@dataclass
class Order:
    order_id: int
    table_number: int
    created_at: datetime = field(default_factory=datetime.now)
    status: OrderStatus = OrderStatus.OPEN
    lines: List[OrderLine] = field(default_factory=list)
    payment: Optional[Payment] = None

    def add_line(self, line: OrderLine) -> None:
        if self.status != OrderStatus.OPEN:
            raise OrderStateError("Добавлять блюда можно только в открытый заказ")
        self.lines.append(line)

    @property
    def total(self) -> float:
        return sum(line.line_total for line in self.lines)

    def pay(self, payment: Payment) -> None:
        if self.status != OrderStatus.OPEN:
            raise OrderStateError("Оплатить можно только открытый заказ")
        if not self.lines:
            raise BusinessRuleError("Нельзя оплатить пустой заказ")
        if round(payment.amount, 2) < round(self.total, 2):
            raise BusinessRuleError("Недостаточная сумма оплаты")
        self.payment = payment
        self.status = OrderStatus.PAID

    def close(self) -> None:
        if self.status != OrderStatus.PAID:
            raise OrderStateError("Закрыть можно только оплаченный заказ")
        self.status = OrderStatus.CLOSED