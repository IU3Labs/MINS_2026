from enum import Enum


class DishCategory(Enum):
    APPETIZER = "Закуски"
    SOUP = "Супы"
    MAIN_COURSE = "Горячее"
    DRINK = "Напитки"
    DESSERT = "Десерты"


class PaymentMethod(Enum):
    CASH = "Наличные"
    CARD = "Карта"
    SBP = "СБП"


class OrderStatus(Enum):
    OPEN = "Открыт"
    PAID = "Оплачен"
    CLOSED = "Закрыт"