from abc import ABC, abstractmethod
from typing import List, Optional

from cafe.domain.entities import MenuItem, CafeTable, Order
from cafe.domain.enums import DishCategory


class MenuRepository(ABC):
    @abstractmethod
    def add(self, item: MenuItem) -> None:
        pass

    @abstractmethod
    def get_by_id(self, item_id: int) -> MenuItem:
        pass

    @abstractmethod
    def list_all(self) -> List[MenuItem]:
        pass

    @abstractmethod
    def list_by_category(self, category: DishCategory) -> List[MenuItem]:
        pass


class TableRepository(ABC):
    @abstractmethod
    def add(self, table: CafeTable) -> None:
        pass

    @abstractmethod
    def get_by_number(self, table_number: int) -> CafeTable:
        pass

    @abstractmethod
    def list_all(self) -> List[CafeTable]:
        pass


class OrderRepository(ABC):
    @abstractmethod
    def add(self, order: Order) -> None:
        pass

    @abstractmethod
    def update(self, order: Order) -> None:
        pass

    @abstractmethod
    def get_by_id(self, order_id: int) -> Order:
        pass

    @abstractmethod
    def get_open_by_table(self, table_number: int) -> Optional[Order]:
        pass

    @abstractmethod
    def list_all(self) -> List[Order]:
        pass