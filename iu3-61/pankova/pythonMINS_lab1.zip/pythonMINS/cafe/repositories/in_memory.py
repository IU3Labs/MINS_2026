from typing import Dict, List, Optional

from cafe.domain.entities import MenuItem, CafeTable, Order
from cafe.domain.enums import DishCategory, OrderStatus
from cafe.exceptions.exceptions import (
    DuplicateError,
    MenuItemNotFoundError,
    TableNotFoundError,
    OrderNotFoundError,
)
from cafe.repositories.interfaces import MenuRepository, TableRepository, OrderRepository


class InMemoryMenuRepository(MenuRepository):
    def __init__(self) -> None:
        self._items: Dict[int, MenuItem] = {}

    def add(self, item: MenuItem) -> None:
        if item.item_id in self._items:
            raise DuplicateError(f"Позиция меню с id={item.item_id} уже существует")
        self._items[item.item_id] = item

    def get_by_id(self, item_id: int) -> MenuItem:
        item = self._items.get(item_id)
        if item is None:
            raise MenuItemNotFoundError(f"Позиция меню с id={item_id} не найдена")
        return item

    def list_all(self) -> List[MenuItem]:
        return sorted(self._items.values(), key=lambda x: x.item_id)

    def list_by_category(self, category: DishCategory) -> List[MenuItem]:
        return [item for item in self.list_all() if item.category == category]


class InMemoryTableRepository(TableRepository):
    def __init__(self) -> None:
        self._tables: Dict[int, CafeTable] = {}

    def add(self, table: CafeTable) -> None:
        if table.table_number in self._tables:
            raise DuplicateError(f"Столик №{table.table_number} уже существует")
        self._tables[table.table_number] = table

    def get_by_number(self, table_number: int) -> CafeTable:
        table = self._tables.get(table_number)
        if table is None:
            raise TableNotFoundError(f"Столик №{table_number} не найден")
        return table

    def list_all(self) -> List[CafeTable]:
        return sorted(self._tables.values(), key=lambda x: x.table_number)


class InMemoryOrderRepository(OrderRepository):
    def __init__(self) -> None:
        self._orders: Dict[int, Order] = {}

    def add(self, order: Order) -> None:
        if order.order_id in self._orders:
            raise DuplicateError(f"Заказ с id={order.order_id} уже существует")
        self._orders[order.order_id] = order

    def update(self, order: Order) -> None:
        if order.order_id not in self._orders:
            raise OrderNotFoundError(f"Заказ с id={order.order_id} не найден")
        self._orders[order.order_id] = order

    def get_by_id(self, order_id: int) -> Order:
        order = self._orders.get(order_id)
        if order is None:
            raise OrderNotFoundError(f"Заказ с id={order_id} не найден")
        return order

    def get_open_by_table(self, table_number: int) -> Optional[Order]:
        for order in self._orders.values():
            if order.table_number == table_number and order.status == OrderStatus.OPEN:
                return order
        return None

    def list_all(self) -> List[Order]:
        return sorted(self._orders.values(), key=lambda x: x.order_id)