from itertools import count
from typing import List

from cafe.domain.entities import Order, OrderLine
from cafe.domain.enums import PaymentMethod
from cafe.exceptions.exceptions import TableOccupiedError
from cafe.payments.factory import PaymentProcessorFactory
from cafe.repositories.interfaces import OrderRepository, TableRepository, MenuRepository


class OrderService:
    def __init__(
        self,
        order_repository: OrderRepository,
        table_repository: TableRepository,
        menu_repository: MenuRepository,
        payment_factory: PaymentProcessorFactory,
    ) -> None:
        self._order_repository = order_repository
        self._table_repository = table_repository
        self._menu_repository = menu_repository
        self._payment_factory = payment_factory
        self._order_id_sequence = count(start=1)

    def create_order_for_table(self, table_number: int) -> Order:
        self._table_repository.get_by_number(table_number)
        existing = self._order_repository.get_open_by_table(table_number)
        if existing is not None:
            raise TableOccupiedError(
                f"У столика №{table_number} уже есть открытый заказ: {existing.order_id}"
            )
        order = Order(order_id=next(self._order_id_sequence), table_number=table_number)
        self._order_repository.add(order)
        return order

    def add_item_to_order(self, order_id: int, item_id: int, quantity: int) -> None:
        order = self._order_repository.get_by_id(order_id)
        item = self._menu_repository.get_by_id(item_id)
        order.add_line(OrderLine(menu_item=item, quantity=quantity))
        self._order_repository.update(order)

    def pay_order(self, order_id: int, method: PaymentMethod, amount: float) -> None:
        order = self._order_repository.get_by_id(order_id)
        payment = self._payment_factory.get(method).create_payment(amount)
        order.pay(payment)
        self._order_repository.update(order)

    def close_order(self, order_id: int) -> None:
        order = self._order_repository.get_by_id(order_id)
        order.close()
        self._order_repository.update(order)

    def get_order(self, order_id: int) -> Order:
        return self._order_repository.get_by_id(order_id)

    def get_all_orders(self) -> List[Order]:
        return self._order_repository.list_all()