from cafe.receipts.formatter import ReceiptFormatter
from cafe.repositories.interfaces import OrderRepository


class ReceiptService:
    def __init__(self, order_repository: OrderRepository, formatter: ReceiptFormatter) -> None:
        self._order_repository = order_repository
        self._formatter = formatter

    def generate_receipt(self, order_id: int) -> str:
        order = self._order_repository.get_by_id(order_id)
        return self._formatter.format(order)