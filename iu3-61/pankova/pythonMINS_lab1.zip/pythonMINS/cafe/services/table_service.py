from typing import List

from cafe.domain.entities import CafeTable
from cafe.repositories.interfaces import TableRepository


class TableService:
    def __init__(self, table_repository: TableRepository) -> None:
        self._table_repository = table_repository

    def add_table(self, table_number: int, seats: int) -> None:
        table = CafeTable(table_number=table_number, seats=seats)
        self._table_repository.add(table)

    def get_tables(self) -> List[CafeTable]:
        return self._table_repository.list_all()

    def get_table(self, table_number: int) -> CafeTable:
        return self._table_repository.get_by_number(table_number)