from cafe.repositories.interfaces import OrderRepository


class ReportService:
    def __init__(self, order_repository: OrderRepository) -> None:
        self._order_repository = order_repository

    def build_sales_report(self) -> str:
        orders = self._order_repository.list_all()
        total_orders = len(orders)
        paid_orders = [order for order in orders if order.payment is not None]
        total_revenue = sum(order.total for order in paid_orders)

        payment_stats: dict[str, int] = {}
        for order in paid_orders:
            method_name = order.payment.method.value
            payment_stats[method_name] = payment_stats.get(method_name, 0) + 1

        lines = [
            "=" * 40,
            "         ОТЧЕТ ПО ЗАКАЗАМ КАФЕ",
            "=" * 40,
            f"Всего заказов: {total_orders}",
            f"Оплаченных заказов: {len(paid_orders)}",
            f"Общая выручка: {total_revenue:.2f} руб.",
            "Способы оплаты:",
        ]

        if payment_stats:
            for method_name, count_value in payment_stats.items():
                lines.append(f"- {method_name}: {count_value}")
        else:
            lines.append("- оплат пока не было")

        lines.append("=" * 40)
        return "\n".join(lines)