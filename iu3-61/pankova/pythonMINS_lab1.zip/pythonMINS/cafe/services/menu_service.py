from typing import List

from cafe.domain.entities import MenuItem
from cafe.domain.enums import DishCategory
from cafe.repositories.interfaces import MenuRepository


class MenuService:
    def __init__(self, menu_repository: MenuRepository) -> None:
        self._menu_repository = menu_repository

    def add_menu_item(
        self,
        item_id: int,
        name: str,
        category: DishCategory,
        price: float,
    ) -> None:
        item = MenuItem(item_id=item_id, name=name, category=category, price=price)
        self._menu_repository.add(item)

    def get_menu(self) -> List[MenuItem]:
        return self._menu_repository.list_all()

    def get_menu_by_category(self, category: DishCategory) -> List[MenuItem]:
        return self._menu_repository.list_by_category(category)