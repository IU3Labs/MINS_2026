from abc import ABC, abstractmethod

from cafe.domain.entities import Order
from cafe.exceptions.exceptions import BusinessRuleError


class ReceiptFormatter(ABC):
    @abstractmethod
    def format(self, order: Order) -> str:
        pass


class TextReceiptFormatter(ReceiptFormatter):
    def format(self, order: Order) -> str:
        if order.payment is None:
            raise BusinessRuleError("Нельзя сформировать чек без оплаты")

        lines = [
            "=" * 40,
            "              ЧЕК КАФЕ",
            "=" * 40,
            f"Номер заказа: {order.order_id}",
            f"Столик: {order.table_number}",
            f"Дата: {order.created_at.strftime('%d.%m.%Y %H:%M:%S')}",
            "-" * 40,
            "Позиции:",
        ]

        for line in order.lines:
            lines.append(
                f"{line.menu_item.name} x{line.quantity} = {line.line_total:.2f} руб."
            )

        lines.extend(
            [
                "-" * 40,
                f"ИТОГО: {order.total:.2f} руб.",
                f"Оплата: {order.payment.method.value}",
                f"Внесено: {order.payment.amount:.2f} руб.",
                f"Сдача: {order.payment.amount - order.total:.2f} руб.",
                "=" * 40,
            ]
        )
        return "\n".join(lines)