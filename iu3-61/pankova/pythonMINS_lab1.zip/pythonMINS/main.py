from cafe.app_builder import AppBuilder

if __name__ == "__main__":
    app = AppBuilder.build()
    app.run()